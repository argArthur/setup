require('cmp').register_source('path', require('cmp_path').new())
