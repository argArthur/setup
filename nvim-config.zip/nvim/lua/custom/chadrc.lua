---@type ChadrcConfig
local M = {}

M.ui = { theme = 'everforest_light' }
M.plugins = "custom.plugins"

return M
